(function() {
  jQuery(function() {
    return $('#expiration').datepicker({
      dateFormat: 'yy-mm-dd'
    });
  });

}).call(this);
